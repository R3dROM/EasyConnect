﻿using EasyConnect.Controllers;
using EasyConnect.Managers;
using EasyConnect.Models;
using EasyConnect.Models.Communication.Message;
using EasyConnect.Models.Progress;
using EasyConnect.Services;
using System.Diagnostics;
using System.Text.Json;
using static EasyConnect.Utilities.Utilities;

namespace EasyConnect.Launcher
{
    public enum States
    {
        NotInitialized,
        Running,
        Initialized
    }
    public class LauncherController(
        NetworkManager _networkManager,
        WebSocketService _websocket,
        ServerController _serverController)
    {
        public States CurrentState { get; set; } = States.NotInitialized;

        private readonly Lock _lock = new ();
        private string startupPaths = string.Empty;

        private bool _inAction = false;
        public bool InAction
        {
            get => _inAction;
            set
            {
                lock (_lock)
                {
                    if (_inAction != value)
                        _inAction = value;
                }
            }
        }
        private bool _isClosing;
        public bool IsClosing
        {
            get => _isClosing;
            set
            {
                lock (_lock)
                {
                    if (_isClosing != value)
                        _isClosing = value;
                }
            }
        }

        public void StartPaths(TextBox caddyPath, TextBox scriptsPath)
        {
            var persistentPath = Application.StartupPath;
            startupPaths = Path.Combine(persistentPath, "startupPaths.json");

            if (!File.Exists(startupPaths))
                return;
            Debug.WriteLine($"string path exists");
            var startupfile = File.ReadAllText(startupPaths, System.Text.Encoding.UTF8);
            if (startupfile == null)
                return;
            Debug.WriteLine($"string path read successfull");
            var paths = JsonSerializer.Deserialize<StartUpPaths>(startupfile);
            if (paths == null)
                return;
            Debug.WriteLine($"string caddypath: {paths.CaddyPath}");
            caddyPath.Text = paths.CaddyPath;
            scriptsPath.Text = paths.ScriptsPath;
        }
        public async Task StartEasyLink(ProgressBar progressBar, ListBox listBox, string caddyPath, string scriptsPath)
        {
            try
            {
                IProgress<ProgressStatus<Stage>> progress = ProgressStatus.ProgressUpdate<Stage>(progressBar, listBox);
                if (CurrentState == States.NotInitialized)
                {
                    CurrentState = States.Running;

                    StartUpPaths newPath = new(
                        caddyPath,
                        scriptsPath
                        );

                    string json = JsonSerializer.Serialize(newPath);
                    Debug.WriteLine($"scripts path: {scriptsPath}");
                    await File.WriteAllTextAsync(startupPaths, json);

                    _networkManager.SetCaddy(caddyPath);
                    _networkManager.SetScriptsPath(scriptsPath);

                    progress.Report(new ProgressStatus<Stage>
                    {
                        Percent = 0,
                        Stage = Stage.Start,
                        Description = "Starting all the services to run the application",
                        IsCompleted = false
                    });

                    await ProgressStatus.Step(progress, 10, 50, Stage.Start,
                        "Starting Server",
                        "Server ready",
                        () => _serverController.StartServer());
                    await ProgressStatus.Step(progress, 50, 100, Stage.Start,
                        "Starting Websocket service",
                        "Websocket service ready",
                        () => _websocket.StartAsync());

                    progress.Report(new ProgressStatus<Stage>
                    {
                        Percent = 100,
                        Stage = Stage.Start,
                        Description = "All Services ready",
                        IsCompleted = true
                    });

                    progressBar.Value = 100;
                    CurrentState = States.Initialized;
                    await Task.Delay(3000);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ERROR SETTING UP THE SERVICES!! {ex}");
                throw new Exception($"ERROR SETTING UP THE SERVICES!! ", ex);
            }
        }
        public async Task CloseEasyLink()
        {
            _isClosing = true;

            try
            {
                Debug.WriteLine("CLOSING EVERYTHING!!");
                _websocket.Close();
                await _serverController.StopServer();
            }
            catch (Exception ex)
            {
                throw new Exception($"ERROR AL CERRAR!! ", ex);
            }
        }
    }
}
