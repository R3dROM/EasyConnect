﻿using EasyConnect.Models.Communication.Message;
using EasyConnect.Models.Configurations;
using EasyConnect.Models.Progress;
using EasyConnect.Services;
using System.Diagnostics;

namespace EasyConnect.Controllers
{
    public class DeployController(
        NetworkService _networkService,
        DeploymentService _deploymentService)
    {
        public async Task StartUninstall(int maxDevices)
        {
            try
            {
                await _deploymentService.StartUninstall(maxDevices);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"EXCEPTION ON UNINSTALLING APP: {ex.Message}");
                throw;
            }
        }
        public async Task StartExperience(int maxDevices)
        {
            try
            {
                await _deploymentService.StartExperience(maxDevices);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"EXCEPTION ON START EXPERIENCE APP: {ex.Message}");
                throw;
            }
        }
        public async Task StartDeployment(int maxDevices)
        {
            try
            {
                await _networkService.GenerateNetworkingConfigurationJson();
                await _deploymentService.StartDeployment(maxDevices);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"EXCEPTION ON DEPLOYMENT APP: {ex.Message}");
                throw;
            }
        }
        public async Task StopDeployment(int maxDevices)
        {
            try
            {
                await _deploymentService.StopDeployment();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"EXCEPTION ON DEPLOYMENT APP: {ex.Message}");
                throw;
            }
        }
    }
}
