﻿using EasyConnect.Managers;
using EasyConnect.Models.Commands;
using EasyConnect.Models.Configurations;
using static EasyConnect.Utilities.Utilities;

namespace EasyConnect.Services
{
    public class NetworkService(
        ConsoleService _consoleService,
        NetworkManager _networkManager,
        DeviceManager _deviceManager)
    {
        private readonly LocalConfigurations localConfigurations = new(_networkManager, _consoleService);
        public async Task StopServerConnection()
        {
            await _consoleService.RunCommandAsync(_networkManager.GetCaddyExe(), $"stop");
        }
        public async Task<ActionResult> StartNetwork()
        {
            try
            {
                await Task.Run(async () =>
                {
                    var ipList = GetMyIpAddress();
                    _networkManager.SetMyIpAddress(ipList.First(
                        ip =>
                        ip.ToString().StartsWith("192.168")
                        ));
                    if (string.IsNullOrEmpty(_networkManager.GetMyIpAddress()))
                        throw new Exception("No ip address found");

                    _ =  _consoleService.RunCommandAsync("powershell.exe", $"Set-Location " +
                        $"'{_networkManager.GetCaddy()}'; & '{_networkManager.GetCaddyExe()}' run --config '{_networkManager.GetCaddyFile()}'");
                });
                return new ActionResult
                {
                    Ip = _networkManager.GetMyIpAddress(),
                    ExitCode = 0,
                    Output = "Network Service Ready"
                };
            }
            catch (Exception)
            {
                return new ActionResult
                {
                    Ip = _networkManager.GetMyIpAddress(),
                    ExitCode = -1,
                    Output = "Network Service Fail"
                };
            }
        }
        public async Task<ActionResult> GenerateNetworkingConfigurationJson()
        {
            var snapshot = _deviceManager.DevicesDictionary;
            return await localConfigurations.GenerateNetworkingConfigurationJson(snapshot);
        }
        public async Task ConfigureDeploymentPaths(string path)
        {
            _networkManager.SetDeployPath(path);
            _networkManager.SetFolderBundle(path);

            await GenerateBundleId(0);
        }
        internal async Task ConfigureDeploymentIp(string ip)
        {
            _networkManager.SetExperienceManagerIp(ip);
        }
        internal async Task GenerateBundleId(int extension)
        {
            await localConfigurations.GenerateBundleId();
        }
    }
}
