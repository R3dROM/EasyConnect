﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EasyConnect.Models.Presentation
{
    public class DeviceSpecificPresentation
    {
    }
}
